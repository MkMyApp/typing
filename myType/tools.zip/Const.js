function composeText() {
  // 1. 各項目の値を取得
  const startMsg = document.getElementById('START_MSG_INPUT').value;
  const inputMsg = document.getElementById('INPUT_MSG_INPUT').value;
  const randomVal = document.getElementById('RANDOM_INPUT').value;
  const widthVal = document.getElementById('WIDTH_INPUT').value;

  // 2. テキストエリアの要素を取得
  const textArea = document.getElementById('result_area');

  // 3. 追加したい「const部分」だけを組み立てる
  const configText = `<script>
const START_MSG = "${startMsg}";
const INPUT_MSG = "${inputMsg}";
const RANDOM = "${randomVal}";
const WIDTH = "${widthVal}";
<\/script>\n`;

  const textVal = textArea.value;

  textArea.value = configText + textVal;
}
