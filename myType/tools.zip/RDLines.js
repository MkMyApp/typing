function processText(text) {
  text = text.replace(/\r\n/g, '\n');

  const lines = text.split('\n');
  const seen = new Set();
  const result = [];

  for (let line of lines) {
    // 空白行はそのまま残す
    if (line.trim() === '') {
      result.push(line);
      continue;
    }

    // 初出のみ残す
    if (!seen.has(line)) {
      seen.add(line);
      result.push(line);
    }
  }

  return result.join('\n');
}

function editText() {
  const textarea = document.getElementById("text");
  textarea.value = processText(textarea.value);
}
