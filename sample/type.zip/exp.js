function expDiv_Display(mode) {
	document.getElementById('exp').style.display = mode;
}

document.getElementById('exp').addEventListener('click', function() {
  expDiv_Display("none")
  document.getElementById('editor').focus();
});

window.addEventListener('keydown', (event) => {
  if (event.key === 'Escape') {
    expDiv_Display("block")
  }
});
